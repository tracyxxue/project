map = [] #setting map as a global variable
previous_locations = []